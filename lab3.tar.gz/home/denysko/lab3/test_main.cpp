// test_main.cpp
#include <iostream>
#include "main.cpp"

int main() {
    std::cout << "Tests passed!" << std::endl;
    return 0;
}

